package com.csus.csc133;

public class StudentCar extends Student {
    private static final double SPEED_MULTIPLIER = 5.0;
    private static final double SWEATING_RATE_MULTIPLIER = 0.0;

    public StudentCar(double x, double y) {
        super(x, y);
        setSpeed(getSpeed() * SPEED_MULTIPLIER);
        setSweatingRate(getSweatingRate() * SWEATING_RATE_MULTIPLIER);
        setHead(90.0);
    }

}
