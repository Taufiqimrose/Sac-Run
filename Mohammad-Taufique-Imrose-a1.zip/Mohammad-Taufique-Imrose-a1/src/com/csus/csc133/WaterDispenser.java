package com.csus.csc133;

public class WaterDispenser extends Facility {
    public WaterDispenser(double x, double y) {
        super(x, y);
    }

    @Override
    public void handleCollide(Student s) {
        s.drinkWater();
    }

}
