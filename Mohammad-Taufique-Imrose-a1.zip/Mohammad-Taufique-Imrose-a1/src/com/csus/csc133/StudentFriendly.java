package com.csus.csc133;

public class StudentFriendly extends Student {
    public StudentFriendly(double x, double y) {
        super(x, y);
        setTalkiveLevel(getTalkiveLevel() / 2);
    }
    
}
