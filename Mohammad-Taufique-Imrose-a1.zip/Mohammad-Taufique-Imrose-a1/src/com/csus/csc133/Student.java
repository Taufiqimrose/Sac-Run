package com.csus.csc133;

import java.util.Random;
import java.util.Vector;

public class Student extends GameObject implements IMoveable {
    private static final double DEFAULT_SPEED = 200.0;
    private static final double DEFAULT_TALKIVELEVEL = 2.0;

    private double head;
    private double speed;
    private double talkiveLevel;
    private double timeRemain;
    private double hydration;
    private double waterIntake;
    private double sweatingRate;
    private int absenceTime;

    
    public Student(double x, double y) {
        super();
        Random random = new Random();
        this.head = random.nextDouble() * 360;
        this.speed = getDefaultSpeed();
        this.talkiveLevel = DEFAULT_TALKIVELEVEL;
        this.timeRemain = 0;
        this.hydration = 200;
        this.waterIntake = 0;
        this.sweatingRate = 3.0;
        this.absenceTime = 0;
    }


    public void drinkWater() {
        hydration = 200;
        waterIntake += (200 - hydration);
    }

    public void goToRestroom() {
        waterIntake = 0;
    }

    public void collide(Student other) {
        double maxTalkiveLevel = Math.max(this.talkiveLevel, other.talkiveLevel);
        this.timeRemain = maxTalkiveLevel;
        other.timeRemain = maxTalkiveLevel;
    }

    @Override
    public void move() {
        if (timeRemain > 0) {
            timeRemain--;
        } else {
            double radians = Math.toRadians(90 - head);
            double dx = Math.cos(radians) * speed;
            double dy = Math.sin(radians) * speed;
            x += dx;
            y += dy;
            hydration -= sweatingRate;
        }
    }


    @Override
    public void handleCollide(Student s) {
        
        throw new UnsupportedOperationException("Unimplemented method 'handleCollide'");
    }
    public double getHead() {
        return head;
    }
    
    public double getX() {
	return x;
    }
    
    public double getY() {
    return y;
    }
    
    public void setHead(double head) {
        this.head = head;
    }

    public double getSpeed() {
        return speed;
    }

    public void setSpeed(double speed) {
        this.speed = speed;
    }

    public double getTalkiveLevel() {
        return talkiveLevel;
    }

    public void setTalkiveLevel(double talkiveLevel) {
        this.talkiveLevel = talkiveLevel;
    }

    public double getTimeRemain() {
        return timeRemain;
    }

    public void setTimeRemain(double timeRemain) {
        this.timeRemain = timeRemain;
    }

    public double getHydration() {
        return hydration;
    }

    public void setHydration(double hydration) {
        this.hydration = hydration;
    }

    public double getWaterIntake() {
        return waterIntake;
    }

    public void setWaterIntake(double waterIntake) {
        this.waterIntake = waterIntake;
    }

    public double getSweatingRate() {
        return sweatingRate;
    }

    public void setSweatingRate(double sweatingRate) {
        this.sweatingRate = sweatingRate;
    }

    public int getAbsenceTime() {
        return absenceTime;
    }

    public void setAbsenceTime(int absenceTime) {
        this.absenceTime = absenceTime;
    }
    public static double getDefaultSpeed() {
        return DEFAULT_SPEED;
        
    }
    public void clearWaterIntake() {
        
        throw new UnsupportedOperationException("Unimplemented method 'clearWaterIntake'");
    }
    
}
