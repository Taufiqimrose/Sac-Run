package com.csus.csc133;

public class StudentAngry extends Student {
    public StudentAngry(double x, double y) {
        super(x, y);
        setTalkiveLevel(getTalkiveLevel() * 2);
    }
    
}
