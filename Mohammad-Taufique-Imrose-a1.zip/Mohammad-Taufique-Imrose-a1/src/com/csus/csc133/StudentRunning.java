package com.csus.csc133;

public class StudentRunning extends Student {
    private static final double SWEATING_RATE = 2.0;

    public StudentRunning(double x, double y) {
        super(x, y);
        setSweatingRate(SWEATING_RATE * 2);
    }
}
