package com.csus.csc133;

public class StudentBiking extends Student {
    private static final double SPEED_MULTIPLIER = 3.0;
    private static final double SWEATING_RATE_MULTIPLIER = 0.0;

    public StudentBiking(double x, double y) {
        super(x, y);
        setSpeed(getSpeed() * SPEED_MULTIPLIER);
        setSweatingRate(getSweatingRate() * SWEATING_RATE_MULTIPLIER);
    }
}
