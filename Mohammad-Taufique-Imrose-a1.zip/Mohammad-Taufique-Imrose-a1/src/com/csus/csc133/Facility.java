package com.csus.csc133;

public class Facility extends GameObject {

    public Facility(double x, double y) {
        super();
        
    }

    @Override
    public void handleCollide(Student s) {
       
        throw new UnsupportedOperationException("Unimplemented method 'handleCollide'");
    }

}
