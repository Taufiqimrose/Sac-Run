package com.csus.csc133;

import java.util.Random;

public class StudentConfused extends Student {
    public StudentConfused(double x, double y) {
        super(x, y);
        randomizeHead();
    }

    @Override
    public void move() {
        randomizeHead();
        super.move();
    }

    private void randomizeHead() {
        Random random = new Random();
        setHead(random.nextDouble() * 360);
    }
}
