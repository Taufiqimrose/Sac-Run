package com.csus.csc133;

public class StudentHappy extends Student {
    private boolean jumping;

    public StudentHappy(double x, double y) {
        super(x, y);
        jumping = false;
    }

    public void jumpForward() {
        if (!jumping) {
            jumping = true;
            setSpeed(getSpeed() * 10);
        }
    }

    @Override
    public void move() {
        super.move();
        if (jumping) {
            jumping = false;
            setSpeed(getSpeed() / 10);
        }
    }
}
