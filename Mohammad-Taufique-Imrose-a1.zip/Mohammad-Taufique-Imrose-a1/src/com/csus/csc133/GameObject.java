package com.csus.csc133;

public abstract class GameObject {
    protected float x;
    protected float y;

    public GameObject() {
        this.x = x;
        this.y = y;
    }

    public abstract void handleCollide(Student s);
}
