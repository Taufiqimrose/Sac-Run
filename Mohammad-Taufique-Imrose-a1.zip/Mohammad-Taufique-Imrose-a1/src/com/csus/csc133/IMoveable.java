package com.csus.csc133;

public interface IMoveable {
    void move();
}