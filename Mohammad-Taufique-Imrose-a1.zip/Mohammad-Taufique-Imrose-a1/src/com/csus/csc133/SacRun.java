package com.csus.csc133;

import com.codename1.ui.*;
import com.codename1.ui.events.*;
import com.csus.csc133.GameModel;

	public class SacRun extends Form{
	
		private GameModel gm;
		
		public SacRun(){
			gm = new GameModel();
			
			A1();
				
			gm.init();
			
		}
	
	//UI provided for A1 only, remove it in A2
	private void A1() {
		Label myLabel=new Label("Enter a Command:");
		TextField myTextField=new TextField();
		this.add(myLabel).add(myTextField);
		this.show();
		myTextField.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent evt) {
				String sCommand=myTextField.getText().toString();
				myTextField.clear();
				if(sCommand.isEmpty()) return;
				handleInput(sCommand.charAt(0));
			}
		});
	}

	private void handleInput(char key) {
		switch (key) {
			
				case 'w':
					// Ask the StudentPlayer to start moving
					gm.handleW();
					break;
				case 's':
					// Ask the StudentPlayer to stop moving
					gm.handleS();
					break;
				case 'a':
					// Ask the StudentPlayer to turn left
					gm.handleA();
					break;
				case 'd':
					// Ask the StudentPlayer to turn right
					gm.handleD();
					break;
				case '1':
					// Pretend collision between StudentPlayer and LectureHall
					gm.handleCollision(null);
					break;
				case '2':
					// Pretend collision between StudentPlayer and Restroom
					gm.handleCollision2(null);
					break;
				case '3':
					// Pretend collision between StudentPlayer and WaterDispenser
					gm.handleCollision3(null);
					break;
				case '4':
					// Pretend collision between StudentPlayer and a randomly selected non-player Student
					gm.simulateCollision();
					break;
				 case 'f':
					//Go to the next frame (next second)
					gm.nextFrame();
					break;
				
			case 'm':
				// Output the game information to the console
				gm.printGameInfo();
				break;
			case 'i':
				// Output name to the console
				System.out.println("Player name: Mohammad Taufique Imrose");
				break;
			default:
				// Undefined or illegal input
				System.out.println("Error: Invalid command");
				break;
		}
	}
}
