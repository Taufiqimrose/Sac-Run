package com.csus.csc133;

public class StudentNonstop extends Student {
    public StudentNonstop(double x, double y) {
        super(x, y);
    }

    @Override
    public void move() {
        // Nonstop students do not move
    }

    @Override
    public void handleCollide(Student s) {
        // Nonstop students do not stop after colliding with others
    }
}
