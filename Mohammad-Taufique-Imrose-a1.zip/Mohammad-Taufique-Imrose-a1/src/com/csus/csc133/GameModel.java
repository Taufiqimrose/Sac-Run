package com.csus.csc133;

import java.util.Vector;
import java.util.Random;


public class GameModel<GameObject> {
    private int width;
    private int height;
    private int gameTime;
    private Vector<GameObject> gameObjects;
    private StudentPlayer studentPlayer = new StudentPlayer(gameTime,gameTime);
    private LectureHall lectureHall;
    private Restroom restroom;
    private WaterDispenser waterDispenser;
    private Random random = new Random();

    public GameModel() {
        // Initialize game model
        width = 1000;
        height = 800;
        gameTime = 0;
        gameObjects = new Vector<GameObject>();
    }
    

    
    public void init() {
    	studentPlayer = new StudentPlayer(0, 0); 
        addGameObject(studentPlayer);
        StudentAngry studentAngry = new StudentAngry(0, 0); 
        addGameObject(studentAngry);
        StudentBiking studentBiking = new StudentBiking(0, 0); 
        addGameObject(studentBiking);
        StudentCar studentCar = new StudentCar(0, 0); 
        addGameObject(studentCar);
        StudentConfused studentConfused = new StudentConfused(0, 0); 
        addGameObject(studentConfused);
        StudentFriendly studentFriendly = new StudentFriendly(0, 0); 
        addGameObject(studentFriendly);
        StudentHappy studentHappy = new StudentHappy(0, 0); 
        addGameObject(studentHappy);
        StudentNonstop studentNonstop = new StudentNonstop(0, 0); 
        addGameObject(studentNonstop);
        StudentSleeping studentSleeping = new StudentSleeping(0, 0); 
        addGameObject(studentSleeping);
        StudentRunning studentRunning = new StudentRunning(0, 0); 
        addGameObject(studentRunning);
    
        lectureHall = new LectureHall(0,0);
        addGameObject(lectureHall);
        this.restroom = new Restroom(0,0);
        addGameObject(restroom);
        this.waterDispenser = new WaterDispenser(0,0);
        addGameObject(waterDispenser);
        
    }

    public void addGameObject(StudentPlayer studentPlayer) {
        gameObjects.add((GameObject) studentPlayer);
        }
    
   public void addGameObject(StudentAngry studentAngry) {
        gameObjects.add((GameObject) studentAngry);
        
    }
   public void addGameObject(StudentBiking studentBiking) {
       gameObjects.add((GameObject) studentBiking);
       
   }
   
   public void addGameObject(StudentCar studentCar) {
       gameObjects.add((GameObject) studentCar);
       
   }
   
   public void addGameObject(StudentConfused studentConfused) {
       gameObjects.add((GameObject) studentConfused);
       
   }
   public void addGameObject(StudentFriendly studentFriendly) {
       gameObjects.add((GameObject) studentFriendly);
       
   }
   public void addGameObject(StudentHappy studentHappy) {
       gameObjects.add((GameObject) studentHappy);
       
   }
   public void addGameObject(StudentNonstop studentNonstop ) {
       gameObjects.add((GameObject) studentNonstop);
       
   }
   public void addGameObject(StudentSleeping studentSleeping ) {
       gameObjects.add((GameObject) studentSleeping);
       
   }
   public void addGameObject(StudentRunning studentRunning ) {
       gameObjects.add((GameObject) studentRunning);
       
   }
   public void addGameObject(LectureHall lectureHall ) {
       gameObjects.add((GameObject) lectureHall);
       
   }
   public void addGameObject(Restroom restroom ) {
       gameObjects.add((GameObject) restroom);
       
   }
   public void addGameObject(WaterDispenser waterDispenser ) {
       gameObjects.add((GameObject) waterDispenser);
       
   }
   public void handleW() {
	   System.out.println("Started moving forward.");
    studentPlayer.startMoving();
}
    public void handleS() {
    	System.out.println("Stopped moving.");
    studentPlayer.stopMoving();
}
    public void handleA() {
    	System.out.println("Turning left.");
    studentPlayer.turnLeft();
}
    public void handleD() {
    	System.out.println("Turning right.");
        studentPlayer.turnRight();
    }

    public void handleCollision(StudentPlayer studentPlayer) {
        System.out.println("StudentPlayer collided with LectureHall");
        lectureHall.handleCollide(studentPlayer);
    }

    public void handleCollision2(StudentPlayer studentPlayer) {
        System.out.println("StudentPlayer collided with Restroom");
        restroom.handleCollide(studentPlayer);
    }
    
    public void handleCollision3(StudentPlayer studentPlayer) {
        System.out.println("StudentPlayer collided with WaterDispenser");
        Student s = studentPlayer;
        if (s != null) {
            waterDispenser.handleCollide(s);
        } else {
            // handle the case where s is null
        }
    }
public void simulateCollision() {
    System.out.println("Simulating collision between StudentPlayer and a randomly selected non-player Student");
    // Get all non-player Student instances
    Vector<Student> nonPlayerStudents = new Vector<>();
    for (GameObject gameObject : gameObjects) {
        if (gameObject instanceof Student && !(gameObject instanceof StudentPlayer)) {
            nonPlayerStudents.add((Student) gameObject);
        }
    }
    
    // Randomly pick a non-player Student instance
    if (!nonPlayerStudents.isEmpty()) {
        Random random = new Random();
        int index = random.nextInt(nonPlayerStudents.size());
        Student nonPlayerStudent = nonPlayerStudents.get(index);
        
        
    }
}
        
public void nextFrame() {
    // 1. Increase game time
    gameTime++;

    int MAX_WATER_INTAKE = 100;
    int MAX_ABSENCES = 50;

     //3. Move all the created GameObject accordingly
    for (GameObject gameObject : gameObjects) {
        ((Student) gameObject).move(); 
    }

    // 4. Check if the game is ended
    if (studentPlayer.getAbsenceTime() > MAX_ABSENCES || studentPlayer.getWaterIntake() > MAX_WATER_INTAKE || studentPlayer.getHydration() <= 0) {
        
        System.out.println("Gameover. Time: " + gameTime);
    }
    else {
    	System.out.println("Game still running. Time: " + gameTime);
    }
}



    public void printGameInfo() {
      
        System.out.println("Current Time: " + gameTime);

        for (GameObject gameObject : gameObjects) {
            if (gameObject instanceof StudentPlayer) {
                StudentPlayer studentPlayer = (StudentPlayer) gameObject;
                String info =  studentPlayer.getClass().getSimpleName() + ", Position: (" + studentPlayer.getX() + ", " + studentPlayer.getY() + ")" +
                              ", Head: " + studentPlayer.getHead() +
                              ", Speed: " + studentPlayer.getSpeed() +
                              ", Hydration: " + studentPlayer.getHydration() +
                              ", TalkiveLevel: " + studentPlayer.getTalkiveLevel() +
                              ", TimeRemain: " + studentPlayer.getTimeRemain() +
                              ", AbsenceTime: " + studentPlayer.getAbsenceTime() +
                              ", WaterIntake: " + studentPlayer.getWaterIntake();
                System.out.println(info);
            }  if (gameObject instanceof StudentAngry) {
                Student student = (StudentAngry) gameObject;
                String info =  student.getClass().getSimpleName() + ", Position: (" + studentPlayer.getX() + ", " + studentPlayer.getY() + ")" +
                              ", Head: " + student.getHead() +
                              ", Speed: " + student.getSpeed() +
                              ", Hydration: " + student.getHydration() +
                              ", TalkiveLevel: " + student.getTalkiveLevel() +
                              ", TimeRemain: " + student.getTimeRemain() +
                              ", AbsenceTime: " + student.getAbsenceTime() +
                              ", WaterIntake: " + student.getWaterIntake();
                System.out.println(info);
            }
             if (gameObject instanceof StudentBiking) {
                Student student = (StudentBiking) gameObject;
                String info =  student.getClass().getSimpleName() + ", Position: (" + studentPlayer.getX() + ", " + studentPlayer.getY() + ")" +
                              ", Head: " + student.getHead() +
                              ", Speed: " + student.getSpeed() +
                              ", Hydration: " + student.getHydration() +
                              ", TalkiveLevel: " + student.getTalkiveLevel() +
                              ", TimeRemain: " + student.getTimeRemain() +
                              ", AbsenceTime: " + student.getAbsenceTime() +
                              ", WaterIntake: " + student.getWaterIntake() + ", Biking";
                System.out.println(info);
            }
             if (gameObject instanceof StudentCar) {
                 Student student = (StudentCar) gameObject;
                 String info =  student.getClass().getSimpleName() + ", Position: (" + studentPlayer.getX() + ", " + studentPlayer.getY() + ")" +
                               ", Head: " + student.getHead() +
                               ", Speed: " + student.getSpeed() +
                               ", Hydration: " + student.getHydration() +
                               ", TalkiveLevel: " + student.getTalkiveLevel() +
                               ", TimeRemain: " + student.getTimeRemain() +
                               ", AbsenceTime: " + student.getAbsenceTime() +
                               ", WaterIntake: " + student.getWaterIntake() + ", Driving";
                 System.out.println(info);
             }
             if (gameObject instanceof StudentConfused) {
                 Student student = (StudentConfused) gameObject;
                 String info =  student.getClass().getSimpleName() + ", Position: (" + studentPlayer.getX() + ", " + studentPlayer.getY() + ")" +
                               ", Head: " + student.getHead() +
                               ", Speed: " + student.getSpeed() +
                               ", Hydration: " + student.getHydration() +
                               ", TalkiveLevel: " + student.getTalkiveLevel() +
                               ", TimeRemain: " + student.getTimeRemain() +
                               ", AbsenceTime: " + student.getAbsenceTime() +
                               ", WaterIntake: " + student.getWaterIntake();
                 System.out.println(info);
             }
             if (gameObject instanceof StudentFriendly) {
                 Student student = (StudentFriendly) gameObject;
                 String info =  student.getClass().getSimpleName() + ", Position: (" + studentPlayer.getX() + ", " + studentPlayer.getY() + ")" +
                               ", Head: " + student.getHead() +
                               ", Speed: " + student.getSpeed() +
                               ", Hydration: " + student.getHydration() +
                               ", TalkiveLevel: " + student.getTalkiveLevel() +
                               ", TimeRemain: " + student.getTimeRemain() +
                               ", AbsenceTime: " + student.getAbsenceTime() +
                               ", WaterIntake: " + student.getWaterIntake();
                 System.out.println(info);
             }
             if (gameObject instanceof StudentHappy) {
                 Student student = (StudentHappy) gameObject;
                 String info =  student.getClass().getSimpleName() + ", Position: (" + studentPlayer.getX() + ", " + studentPlayer.getY() + ")" +
                               ", Head: " + student.getHead() +
                               ", Speed: " + student.getSpeed() +
                               ", Hydration: " + student.getHydration() +
                               ", TalkiveLevel: " + student.getTalkiveLevel() +
                               ", TimeRemain: " + student.getTimeRemain() +
                               ", AbsenceTime: " + student.getAbsenceTime() +
                               ", WaterIntake: " + student.getWaterIntake();
                 System.out.println(info);
             }
             if (gameObject instanceof StudentNonstop) {
                 Student student = (StudentNonstop) gameObject;
                 String info =  student.getClass().getSimpleName() + ", Position: (" + studentPlayer.getX() + ", " + studentPlayer.getY() + ")" +
                               ", Head: " + student.getHead() +
                               ", Speed: " + student.getSpeed() +
                               ", Hydration: " + student.getHydration() +
                               ", TalkiveLevel: " + student.getTalkiveLevel() +
                               ", TimeRemain: " + student.getTimeRemain() +
                               ", AbsenceTime: " + student.getAbsenceTime() +
                               ", WaterIntake: " + student.getWaterIntake();
                 System.out.println(info);
             }
             if (gameObject instanceof StudentSleeping) {
                 Student student = (StudentSleeping) gameObject;
                 String info =  student.getClass().getSimpleName() + ", Position: (" + studentPlayer.getX() + ", " + studentPlayer.getY() + ")" +
                               ", Head: " + student.getHead() +
                               ", Speed: " + student.getSpeed() +
                               ", Hydration: " + student.getHydration() +
                               ", TalkiveLevel: " + student.getTalkiveLevel() +
                               ", TimeRemain: " + student.getTimeRemain() +
                               ", AbsenceTime: " + student.getAbsenceTime() +
                               ", WaterIntake: " + student.getWaterIntake() + ", zzzZZZ!";
                 System.out.println(info);
        }
             if (gameObject instanceof StudentRunning) {
                 Student student = (StudentRunning) gameObject;
                 String info =  student.getClass().getSimpleName() + ", Position: (" + studentPlayer.getX() + ", " + studentPlayer.getY() + ")" +
                               ", Head: " + student.getHead() +
                               ", Speed: " + student.getSpeed() +
                               ", Hydration: " + student.getHydration() +
                               ", TalkiveLevel: " + student.getTalkiveLevel() +
                               ", TimeRemain: " + student.getTimeRemain() +
                               ", AbsenceTime: " + student.getAbsenceTime() +
                               ", WaterIntake: " + student.getWaterIntake() + ", Running";
                 System.out.println(info);
        }
             if (gameObject instanceof LectureHall) {
                 LectureHall lectureHall = (LectureHall) gameObject;
                 String info =  lectureHall.getClass().getSimpleName() + ", Position: (" + studentPlayer.getX() + ", " + studentPlayer.getY() + ")" +","
                		 +","+lectureHall.getName() +","+lectureHall.getTime();
                             
                             
                 System.out.println(info);
        }
             if (gameObject instanceof Restroom) {
            	 Restroom restroom = (Restroom) gameObject;
                 String info =  restroom.getClass().getSimpleName() + ", Position: (" + studentPlayer.getX() + ", " + studentPlayer.getY() + ")";
                		
                             
                             
                 System.out.println(info);
        }
             if (gameObject instanceof WaterDispenser) {
            	 WaterDispenser waterDispenser = (WaterDispenser) gameObject;
                 String info =  waterDispenser.getClass().getSimpleName() + ", Position: (" + studentPlayer.getX() + ", " + studentPlayer.getY() + ")";
                		
                             
                             
                 System.out.println(info);
        }
    }

    }}

    

    
 
