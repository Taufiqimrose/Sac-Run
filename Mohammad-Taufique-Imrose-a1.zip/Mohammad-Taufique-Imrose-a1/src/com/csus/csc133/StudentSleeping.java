package com.csus.csc133;

public class StudentSleeping extends Student {
    public StudentSleeping(double x, double y) {
        super(x, y);
    }

    @Override
    public void move() {
        // Sleeping students do not move
    }

    @Override
    public void handleCollide(Student s) {
        // Sleeping students do not handle collisions
    }

}
