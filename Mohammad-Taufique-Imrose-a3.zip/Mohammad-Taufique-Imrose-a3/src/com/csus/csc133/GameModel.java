package com.csus.csc133;

import java.util.Vector;

import com.codename1.ui.Button;
import com.codename1.ui.CN;
import com.codename1.ui.Command;
import com.codename1.ui.Dialog;
import com.codename1.ui.Display;
import com.codename1.ui.Form;
import com.codename1.ui.TextField;
import com.codename1.ui.layouts.BoxLayout;

import java.util.Random;
import java.util.Iterator;
import java.util.Observable;
import java.util.Observer;




public class GameModel extends Observable {
   

	private int height = 1280;
	private int width = 720 ;
    private int gameTime;
    private GameObjectCollection gameObjects;
    private StudentPlayer studentPlayer = new StudentPlayer(0,0);
    private LectureHall lectureHall = new LectureHall(0,0,0);
    private Restroom restroom;
    private WaterDispenser waterDispenser;
    private Random random = new Random();
    private ViewStatus viewStatus;
    private GameModel gm;
    private ViewMessage viewMessage;
    private ViewMap mapview;
    private int updatedTime;
    private Student student;
    private boolean isPaused = false;
    private MovementStrategy[] strategies = { new RandomMovementStrategy(), new VerticalMovementStrategy(), new HorizontalMovementStrategy() };
    
    
    

    public int getGameTime() {
		return gameTime;
	}
   
    public int getWidth() {
		return width;
	}

	
	public int getHeight() {
		return height;
	}

   

    public GameModel() {
        // Initialize game model
    	
    	ViewMap mapView = new ViewMap(1000, 800, gm);
    	viewStatus = new ViewStatus(this,student,lectureHall);
        viewMessage = new ViewMessage();
        gameTime = 10;
        gameObjects = new GameObjectCollection();
        addObserver(mapView);
        addObserver(viewStatus);
        addObserver(viewMessage);
        
        init();
        
    }
    
 

    
    public void init() {
    	int OBJECT_SIZE = 60;
    	Random random = new Random();
    	int studentX =  random.nextInt(getWidth() - OBJECT_SIZE); 
        int studentY = random.nextInt(getHeight() - OBJECT_SIZE);
        int studentX1 =  random.nextInt(getWidth() - OBJECT_SIZE); 
        int studentY1 = random.nextInt(getHeight() - OBJECT_SIZE);
        int studentX2 =  random.nextInt(getWidth() - OBJECT_SIZE); 
        int studentY2 = random.nextInt(getHeight() - OBJECT_SIZE);
        int studentX3 =  random.nextInt(getWidth() - OBJECT_SIZE); 
        int studentY3 = random.nextInt(getHeight() - OBJECT_SIZE);
        int studentX4 =  random.nextInt(getWidth() - OBJECT_SIZE); 
        int studentY4 = random.nextInt(getHeight() - OBJECT_SIZE);
        int studentX5 =  random.nextInt(getWidth() - OBJECT_SIZE); 
        int studentY5 = random.nextInt(getHeight() - OBJECT_SIZE);
        int studentX6 =  random.nextInt(getWidth() - OBJECT_SIZE); 
        int studentY6 = random.nextInt(getHeight() - OBJECT_SIZE);
        int studentX7 =  random.nextInt(getWidth() - OBJECT_SIZE); 
        int studentY7 = random.nextInt(getHeight() - OBJECT_SIZE);
        int studentX8 =  random.nextInt(getWidth() - OBJECT_SIZE); 
        int studentY8 = random.nextInt(getHeight() - OBJECT_SIZE);
        int studentX9 =  random.nextInt(getWidth() - OBJECT_SIZE); 
        int studentY9 = random.nextInt(getHeight() - OBJECT_SIZE);
        int studentX10 =  random.nextInt(getWidth() - OBJECT_SIZE); 
        int studentY10 = random.nextInt(getHeight() - OBJECT_SIZE);
        
    	student = new Student(studentX10,studentY10, 0);
    	lectureHall = new LectureHall(700, 320,0);
    	studentPlayer = new StudentPlayer(500,400);
    	gameObjects.add(studentPlayer);
        gameObjects.add(new StudentAngry(studentX1,studentY1));
        gameObjects.add(new StudentBiking(studentX2,studentY2));
        gameObjects.add(new StudentCar(studentX3,studentY3));
        gameObjects.add(new StudentConfused(studentX4,studentY4));
        gameObjects.add(new StudentFriendly(studentX5,studentY5));
        gameObjects.add(new StudentHappy(studentX6,studentY6));
        gameObjects.add(new StudentNonstop(studentX7,studentY7));
        gameObjects.add(new StudentSleeping(studentX8,studentY8));
        gameObjects.add(new StudentRunning(studentX9,studentY9));
        gameObjects.add(new LectureHall(studentX,studentY,0));
        gameObjects.add(new Restroom(studentX,studentY));
        gameObjects.add(new WaterDispenser(studentX,studentY));
        gameObjects.add(new StudentStrategy(0, 0, 0));
        
        updateViews();

    }
    
    public GameObjectCollection getGameObjects() {
        return gameObjects;
    }
    
    public void updateGameTime(int newTime) {
        gameTime = newTime;
        setChanged(); // Marks the object as changed
        notifyObservers(); // Notifies observers of the change
    }
    
    public void updateViews() {
        setChanged();
        notifyObservers();
    }
    
   public void handleW() {
	   ViewMessage.setMessage("Started moving forward.");
    studentPlayer.startMoving();
    updateViews();
}
    public void handleS() {
    	ViewMessage.setMessage("Stopped moving.");
    studentPlayer.stopMoving();
    updateViews();
}
    public void handleA() {
    	 
    	ViewMessage.setMessage("Turning left.");
    studentPlayer.turnLeft();
    updateViews();
    	 
}
    public void handleD() {
    	ViewMessage.setMessage("Turning right.");
        studentPlayer.turnRight();
        updateViews();
    }

    public void handleCollision(StudentPlayer studentPlayer) {
        ViewMessage.setMessage("StudentPlayer collided with LectureHall");
        if (lectureHall != null) {
            lectureHall.handleCollide(studentPlayer);
            updateViews();
        } else {
            // Handle the case where lectureHall is null
            
        }
    }

    public void handleCollision2(StudentPlayer studentPlayer) {
        ViewMessage.setMessage("StudentPlayer collided with Restroom");
        if (restroom != null) {
            restroom.handleCollide(studentPlayer);
            updateViews();
        } else {
            // Handle the case where restroom is null
        }
    }
    
    public void handleCollision3(StudentPlayer studentPlayer) {
    	ViewMessage.setMessage("StudentPlayer collided with WaterDispenser");
        Student s = studentPlayer;
        if (s != null) {
            waterDispenser.handleCollide(s);
            updateViews();
        } else {
            // handle the case where s is null
        }
    }
    public void simulateCollision() {
        ViewMessage.setMessage("Simulating collision between StudentPlayer and a randomly selected non-player Student");
    
        // Get all non-player Student instances
        Vector<Student> nonPlayerStudents = new Vector<>();
        Iterator<GameObject> iterator = gameObjects.iterator();
        while (iterator.hasNext()) {
            GameObject gameObject = iterator.next();
            if (gameObject instanceof Student && !(gameObject instanceof StudentPlayer)) {
                nonPlayerStudents.add((Student) gameObject);
            }
        }
    
        // Randomly pick a non-player Student instance
        if (!nonPlayerStudents.isEmpty()) {
            Random random = new Random();
            int index = random.nextInt(nonPlayerStudents.size());
            Student nonPlayerStudent = nonPlayerStudents.get(index);
            
        }
    
        updateViews(); 
    }
    
    
    
        
    public void nextFrame() {
        // 1. Increase game time
    	
    	if (isPaused) {
            return; // Exit the method if the game is paused
        }
    	
        updatedTime = gameTime++;
        updateViews();
        
        int MAX_WATER_INTAKE = 100;
        int MAX_ABSENCES = 50;

        // 2. Move all the created GameObject accordingly
        Iterator<GameObject> iterator = gameObjects.iterator();
        while (iterator.hasNext()) {
            GameObject gameObject = iterator.next();
            if (gameObject instanceof Student) {
                // Check if it's the student player
                if (gameObject == studentPlayer) {
                    // If it's the player, check if it should stop moving
                    if (studentPlayer.stopMoving()) {
                        // Stop moving the player
                        continue;
                    }
                }
                // Move other students
                ((Student) gameObject).move();
                updateViews();
            }
        }

        // 3. Check if the game is ended
        if (studentPlayer.getAbsenceTime() > MAX_ABSENCES || studentPlayer.getWaterIntake() > MAX_WATER_INTAKE || studentPlayer.getHydration() <= 0) {
        } else {
            updateViews();
        }
    }
    
    public void selectStudent() {
        Dialog dialog = new Dialog("Select Student");
        dialog.setLayout(new BoxLayout(BoxLayout.Y_AXIS));

        TextField textField = new TextField();
        textField.setHint("Enter student number (0-9)");

        Button okButton = new Button("OK");
        okButton.addActionListener(e -> {
            try {
                int studentNumber = Integer.parseInt(textField.getText());
                if (studentNumber >= 0 && studentNumber <= 9) {
                    
                	ViewMessage.setMessage("Selected student: " + studentNumber);
                    dialog.dispose(); 
                } else {
                    // Invalid input
                    Dialog.show("Invalid Input", "Please enter a number between 0 and 9", "OK", null);
                }
            } catch (NumberFormatException ex) {
                // Invalid input
                Dialog.show("Invalid Input", "Please enter a valid number.", "OK", null);
            }
        });

        dialog.add(textField);
        dialog.add(okButton);
        dialog.show();
    }

       
    
    public void togglePause() {
        isPaused = true;
        ViewMessage.setMessage("Game is Paused");
    }
    public void togglePause2() {
    	isPaused = false;
        nextFrame();
    }

    public void showAbout() {
        
        Dialog.show("About", "This is A3\nAuthor: Mohammad Taufique Imrose\nSemester: Spring 2024", "Confirm", null);
    }

    public void confirmExit() {
        boolean confirmed = Dialog.show("Confirm Exit", "Are you sure you want to exit?", "Yes", "No");
        if (confirmed) {
            CN.exitApplication();
        }
    }
    public void setViewStatus(ViewStatus viewStatus) {
        this.viewStatus = viewStatus;
    }
    
   

    public void setViewMessage(ViewMessage viewMessage) {
        this.viewMessage = viewMessage;
    }

  
    public void changeStrategiesRandomly() {
        MovementStrategy[] strategies = {new RandomMovementStrategy(), new VerticalMovementStrategy(), new HorizontalMovementStrategy()};
        Random random = new Random();
        
        
        // Change strategies randomly for all StudentStrategy objects
        for (GameObject gameObject : gameObjects) {
            if (gameObject instanceof StudentStrategy) {
                StudentStrategy studentStrategy = (StudentStrategy) gameObject;
                int randomIndex = random.nextInt(strategies.length);
                MovementStrategy randomStrategy = strategies[randomIndex];
                studentStrategy.changeStrategy(randomStrategy, randomStrategy.getStrategyName());
                Dialog.show("Changed strategy", "Position: (" + studentStrategy.getX() + ", " + studentStrategy.getY() + ") New Strategy: " + randomStrategy.getStrategyName(), "OK", null); //
            }
        }
        updateViews(); // Update views after changing strategies
        
    }




}
    
 
