package com.csus.csc133;

public class StudentFriendly extends Student {
    public StudentFriendly(int x, int y) {
        super(x, y, y);
        setTalkiveLevel(getTalkiveLevel() / 2);
    }
    
}
