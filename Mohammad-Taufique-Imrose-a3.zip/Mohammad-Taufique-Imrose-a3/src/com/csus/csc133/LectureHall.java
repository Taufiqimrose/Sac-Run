package com.csus.csc133;

import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;

class LectureHall extends Facility {
    private String name;
    private Lecture currentLecture;
    private int timeRemaining; // Changed to int to hold the remaining time in seconds

    private static final String[] LECTURE_NAMES = {
        "CSC 133", "CSC 134", "CSC 135", "CSC 137", "CSC 138"
    };

    public LectureHall(int x, int y, int initialTimeInSeconds) {
        super(x, y);
        Random random = new Random();
        this.name = LECTURE_NAMES[random.nextInt(LECTURE_NAMES.length)];
        this.currentLecture = currentLecture;
        this.timeRemaining = initialTimeInSeconds; // Set initial time
        startTimer(); // Start the timer
    }

    private void startTimer() {
        Timer timer = new Timer();
        // Schedule a task to decrement the timeRemaining by 1 every second
        timer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                if (timeRemaining > 0) {
                    timeRemaining--;
                } else {
                    // Time is up, end the lecture or handle as needed
                    currentLecture.end();
                    timer.cancel(); // Stop the timer
                }
            }
        }, 1000, 1000); // Delay 1 second, repeat every 1 second
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Lecture getCurrentLecture() {
        return currentLecture;
    }

    public void setCurrentLecture(Lecture currentLecture) {
        this.currentLecture = currentLecture;
    }

    @Override
    public void handleCollide(Student s) {
        if (s instanceof StudentPlayer) {
            currentLecture.end();
        }
    }

    public int getTimeRemaining() {
        return timeRemaining;
    }

    public void setTimeRemaining(int timeRemaining) {
        this.timeRemaining = timeRemaining;
    }
}
