package com.csus.csc133;

public class StudentPlayer extends Student {
    private boolean isMoving;
    
    
    public StudentPlayer(int x, int y) {
        super(x, y, y);
        this.isMoving = false;
    }
    
    public void startMoving() {
        this.isMoving = true;
        setSpeed(getDefaultSpeed());
        y = y-5;
    }
    
    public boolean stopMoving() {
        this.isMoving = false;
        setSpeed(0);
		return isMoving;
    }
    
    public void turnLeft() {
        x = x-5;
    }
    
    public void turnRight() {
    	x = x+5;
    }
    public void handleCollide(Student s) {
        Super(x, y);
        setTalkiveLevel(getTalkiveLevel() * 2);
        }

    private void Super(float x, float y) {
       
        throw new UnsupportedOperationException("Unimplemented method 'Super'");
    }
    }

