package com.csus.csc133;

class Restroom extends Facility {
    public Restroom(int x, int y) {
        super(x, y);
    }

    @Override
    public void handleCollide(Student s) {
        if (s instanceof StudentPlayer) {
            s.clearWaterIntake();
        }
    }
}
