package com.csus.csc133;

import com.codename1.ui.Command;
import com.codename1.ui.events.ActionEvent;

public class GameCommand extends Command {
    private final GameModel gameModel;
    private final String command;
 

    public GameCommand(GameModel gameModel , String command) {
        super(command);
        this.gameModel = gameModel;
        this.command = command;
		
    }

    @Override
    public void actionPerformed(ActionEvent evt) {
        switch (command) {
            case "Move":
                gameModel.handleW();
                break;
            case "Stop":
                gameModel.handleS();
                break;
            case "Left":
                gameModel.handleA();
                break;
            case "Right":
                gameModel.handleD();
                break;
            case "Pause":
                gameModel.togglePause();
                break;
            case "Resume":
                gameModel.togglePause2();
                break;
            case "Water Dispenser":
                gameModel.handleCollision3(null);
                break;
            case "Student":
                gameModel.selectStudent();
                break;
            case "Next Frame":
                gameModel.nextFrame();
                break;
            case "About":
                gameModel.showAbout();
                break;
            case "Exit":
                gameModel.confirmExit();
                break;
            case "Change Strategies":
                gameModel.changeStrategiesRandomly();
                break;
            default:
                // Handle unrecognized commands
                break;
        }
    }
}
