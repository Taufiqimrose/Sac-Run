package com.csus.csc133;

public class RandomMovementStrategy implements MovementStrategy {
    @Override
    public void apply(StudentStrategy student) {
    	System.out.println("Current Strategy: " + getStrategyName());
    }

    @Override
    public String getStrategyName() {
        return "Random Strategy";
    }
}
