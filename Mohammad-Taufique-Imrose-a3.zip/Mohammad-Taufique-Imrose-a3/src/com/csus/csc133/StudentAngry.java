package com.csus.csc133;

public class StudentAngry extends Student {
    public StudentAngry(int x, int y) {
        super(x, y, y);
        setTalkiveLevel(getTalkiveLevel() * 2);
    }
    
}
