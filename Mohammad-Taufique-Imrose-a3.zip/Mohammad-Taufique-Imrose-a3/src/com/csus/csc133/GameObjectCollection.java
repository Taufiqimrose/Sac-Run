package com.csus.csc133;

import java.util.Iterator;
import java.util.NoSuchElementException;

public class GameObjectCollection implements Iterable<GameObject> {
    private GameObject[] gameObjects;
    private int size;

    public GameObjectCollection() {
        gameObjects = new GameObject[20];
        size = 0;
    }

    public void add(GameObject gameObject) {
        if (size == gameObjects.length) {
            expandArray();
        }
        gameObjects[size++] = gameObject;
    }

    private void expandArray() {
        GameObject[] newArray = new GameObject[gameObjects.length * 2];
        System.arraycopy(gameObjects, 0, newArray, 0, size);
        gameObjects = newArray;
    }

    @Override
    public Iterator<GameObject> iterator() {
        return new GameObjectIterator();
    }

    private class GameObjectIterator implements Iterator<GameObject> {
        private int currentIndex;

        @Override
        public boolean hasNext() {
            return currentIndex < size;
        }

        @Override
        public GameObject next() {
            if (!hasNext()) {
                throw new NoSuchElementException("No more elements in the collection.");
            }
            return gameObjects[currentIndex++];
        }

		@Override
		public void remove() {
			// TODO Auto-generated method stub
			
		}
    }
}
