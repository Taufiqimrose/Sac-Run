package com.csus.csc133;
import com.csus.csc133.Student; // Add missing import statement


public class WaterDispenser extends Facility {
    public WaterDispenser(int x, int y) {
        super(x, y);
    }

    @Override
    public void handleCollide(Student s) {
        s.drinkWater();
    }

}
