package com.csus.csc133;

import java.util.Random;

public class StudentStrategy extends Student {
    private MovementStrategy currentStrategy;
    private String strategyName;

    public StudentStrategy(int x, int y, int timeRemain) {
        super(x, y, timeRemain);
        setRandomStrategy();
    }

    // Method to set a random strategy
    private void setRandomStrategy() {
        Random random = new Random();
        int strategyIndex = random.nextInt(3); 
        switch (strategyIndex) {
            case 0:
                currentStrategy = new RandomMovementStrategy();
                strategyName = "Random";
                break;
            case 1:
                currentStrategy = new VerticalMovementStrategy();
                strategyName = "Vertical";
                break;
            case 2:
                currentStrategy = new HorizontalMovementStrategy();
                strategyName = "Horizontal";
                break;
            default:
              
                break;
        }
    }

    // Method to change strategy
    public void changeStrategy(MovementStrategy newStrategy, String newStrategyName) {
        this.currentStrategy = newStrategy;
        this.strategyName = newStrategyName;
    }

    @Override
    public void move() {
        // Apply the current strategy before moving
        if (currentStrategy != null) {
            currentStrategy.apply(this);
        }
        
        super.move();
    }

    // Method to get the current strategy name
    public String getCurrentStrategyName() {
        return strategyName;
    }
}
