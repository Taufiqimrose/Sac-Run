package com.csus.csc133;

import java.util.ArrayList;
import java.util.Observable;
import java.util.Observer;

import com.codename1.ui.Container;
import com.codename1.ui.Graphics;
import com.codename1.ui.plaf.Border;
import com.codename1.ui.plaf.Style;
import com.csus.csc133.GameObject;


public class ViewMap extends Container implements Observer {
      
    private GameModel gm;
    private static final int OBJECT_SIZE = 80; // Fixed size for all game objects
    private LectureHall lectureHall = new LectureHall(0,0,0);
    private String name = lectureHall.getName();

    public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public ViewMap(int width, int height, GameModel gm) {
    	this.gm = gm;
        if (this.gm != null) {
            this.gm.addObserver(this); // Register this view as an observer of the game model
        } // Register this view as an observer of the game model
        
        Style style = getAllStyles();
        style.setBorder(Border.createLineBorder(2, 0xff0000));
    }

    @Override
	public void paint(Graphics g) {
        super.paint(g);
        
        // Draw all game objects
        GameObjectCollection gameObjects = gm.getGameObjects();
        for (GameObject gameObject : gameObjects) {
            drawGameObject(g, gameObject);
        }
    }


    private void drawGameObject(Graphics g, GameObject gameObject) {
        int x = gameObject.getX();
        int y = gameObject.getY();
        
        if (gameObject instanceof LectureHall) {
            drawLectureHall(g,(LectureHall) gameObject, x, y);
        } else if (gameObject instanceof WaterDispenser) {
            drawWaterDispenser(g, x, y);
        } else if (gameObject instanceof Restroom) {
            drawRestroom(g, x, y);
        } else if (gameObject instanceof Student) {
            drawStudent(g, (Student) gameObject, x, y);
        } else if (gameObject instanceof StudentPlayer) {
            drawStudentPlayer(g, (StudentPlayer) gameObject, x, y);
        }
    }

    private void drawLectureHall(Graphics g, LectureHall gameObject, int x, int y) {
        g.setColor(0x0000FF); // Blue color
        x= 600;
        y= 700;
        g.fillRect(x, y, OBJECT_SIZE, OBJECT_SIZE); // Draw a square
        g.setColor(0x000000); // Black color
        g.drawString(name, x, y + OBJECT_SIZE + 10);
    }

    private void drawWaterDispenser(Graphics g, int x, int y) {
    	x = 400;
    	y = 300;
        g.setColor(0x0000FF); // Blue color
        g.fillArc(x, y, OBJECT_SIZE, OBJECT_SIZE, 0, 360);
    }

    private void drawRestroom(Graphics g, int x, int y) {
    	x = 200;
    	y = 100;
        g.setColor(0x00FF00); // Green color
        g.fillRect(x, y, OBJECT_SIZE, OBJECT_SIZE);
    }

    private void drawStudent(Graphics g, Student student, int x, int y) {
        g.setColor(0x0000FF);
        int[] xPoints = {x, x + OBJECT_SIZE / 2, x + OBJECT_SIZE};
        int[] yPoints = {y + OBJECT_SIZE, y, y + OBJECT_SIZE};
        g.drawPolygon(xPoints, yPoints, 3);
    }

    private void drawStudentPlayer(Graphics g, StudentPlayer studentPlayer, int x, int y) {
        g.setColor(0x00FF00);
        int[] xPoints = {x, x + OBJECT_SIZE / 2, x + OBJECT_SIZE};
        int[] yPoints = {y + OBJECT_SIZE, y, y + OBJECT_SIZE};
        g.fillPolygon(xPoints, yPoints, 3);
    }
    @Override
    public void update(Observable observable, Object data) {
        // Repaint the view when the game model is updated
        repaint();
    }

}
