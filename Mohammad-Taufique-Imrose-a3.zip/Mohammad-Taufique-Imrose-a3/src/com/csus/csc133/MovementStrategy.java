package com.csus.csc133;

public interface MovementStrategy {
    void apply(StudentStrategy student);

    String getStrategyName();
}