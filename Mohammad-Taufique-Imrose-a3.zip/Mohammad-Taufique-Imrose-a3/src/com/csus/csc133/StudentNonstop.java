package com.csus.csc133;

public class StudentNonstop extends Student {
    public StudentNonstop(int x, int y) {
        super(x, y, y);
    }

    @Override
    public void move() {
        // Nonstop students do not move
    }

    
   
}
