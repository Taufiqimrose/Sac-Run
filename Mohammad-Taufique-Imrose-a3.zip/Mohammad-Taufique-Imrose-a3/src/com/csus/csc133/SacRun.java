package com.csus.csc133;

import com.codename1.ui.*;
import com.codename1.ui.events.*;
import com.codename1.ui.geom.Dimension;
import com.codename1.ui.layouts.BorderLayout;
import com.codename1.ui.layouts.BoxLayout;
import com.codename1.ui.layouts.GridLayout;
import com.codename1.ui.plaf.Border;
import com.codename1.ui.plaf.Style;
import com.codename1.ui.plaf.UIManager;
import com.codename1.ui.util.UITimer;
import com.csus.csc133.GameModel;
import com.csus.csc133.ButtonStyles;
import com.codename1.ui.events.ActionEvent;
import com.codename1.ui.events.ActionListener;
import com.codename1.ui.Component;
import com.codename1.ui.Display;



public class SacRun extends Form implements Runnable {

    private GameModel gm;
    private ViewMap viewMap;
    private Student student;
    private LectureHall lectureHall;
    private UITimer timer;
    private static final int TIMER_INTERVAL = 1000;
    
    public SacRun() {
        
    	
        // Initialize the GameModel with ViewMap's width and height
        gm = new GameModel();
        gm.init();
        
        // Set up the layout and add components
        A2();
        
        timer = new UITimer(this);
        
        timer.schedule(TIMER_INTERVAL, true, this);

        // Show the form
        show();
        Form mainForm = Display.getInstance().getCurrent();

     // Add key listeners
     mainForm.addKeyListener('w', e -> {
         // Call the method to start moving the StudentPlayer
         gm.handleW();
     });

     mainForm.addKeyListener('a', e -> {
         // Call the method to turn the StudentPlayer left
    	 gm.handleA();
     });

     mainForm.addKeyListener('s', e -> {
         // Call the method to stop moving the StudentPlayer
    	 gm.handleS();
     });

     mainForm.addKeyListener('d', e -> {
         // Call the method to turn the StudentPlayer right
    	 gm.handleD();
     
     });
        
    }

    private void A2() {
        // Create the GUI components
    	// Initialize the ViewMap
        viewMap = new ViewMap(0,0, gm);

        ViewStatus viewStatus = new ViewStatus(gm,student,lectureHall);

        ViewMessage viewMessage = new ViewMessage();
        ViewMessage.setMessage("Welcome! CSC 133-01 | Assignment 3 - Mohammad Taufique Imrose");

        // Set up the layout of the form
        setLayout(new BorderLayout());
        Container eastContainer = new Container(new BoxLayout(BoxLayout.Y_AXIS));
        Container westContainer = new Container(new GridLayout(3, 1));
        Container centerContainer = new Container(new BorderLayout());
        Container southContainer = new Container(new BorderLayout());

        // Add the GUI components to the containers
        eastContainer.add(viewStatus);
        centerContainer.add(BorderLayout.CENTER, viewMap);
        southContainer.add(BorderLayout.CENTER, viewMessage);

        // Add the containers to the form
        add(BorderLayout.EAST, eastContainer);
        add(BorderLayout.WEST, westContainer);
        add(BorderLayout.CENTER, centerContainer);
        add(BorderLayout.SOUTH, southContainer);

     // Create buttons
        Button moveButton = new Button("Move");
        Button stopButton = new Button("Stop");
        Button turnLeftButton = new Button("Turn Left");
        Button turnRightButton = new Button("Turn Right");
        Button pauseButton = new Button("Pause");
        Button resumeButton = new Button("Resume");
        Button changeStrategiesButton = new Button("Change Strategies");
        
        Button aboutButton = new Button("About");
        Button exitButton = new Button("Exit");
        
        Dimension buttonSize = new Dimension(450, 50); // Adjust the width and height as needed
        moveButton.setPreferredSize(buttonSize);
        stopButton.setPreferredSize(buttonSize);
        turnLeftButton.setPreferredSize(buttonSize);
        turnRightButton.setPreferredSize(buttonSize);
        pauseButton.setPreferredSize(buttonSize);
        resumeButton.setPreferredSize(buttonSize);
        aboutButton.setPreferredSize(buttonSize);
        exitButton.setPreferredSize(buttonSize);
        
        // Apply primary button style to each button
        ButtonStyles.applyPrimaryButtonStyle(moveButton);
        ButtonStyles.applyPrimaryButtonStyle(stopButton);
        ButtonStyles.applyPrimaryButtonStyle(turnLeftButton);
        ButtonStyles.applyPrimaryButtonStyle(turnRightButton);
        ButtonStyles.applyPrimaryButtonStyle(changeStrategiesButton);
        ButtonStyles.applyPrimaryButtonStyle(pauseButton);
        ButtonStyles.applyPrimaryButtonStyle(resumeButton);
        ButtonStyles.applyPrimaryButtonStyle(aboutButton);
        ButtonStyles.applyPrimaryButtonStyle(exitButton);


        // Add the command buttons to the west container
        westContainer.add(moveButton);
        westContainer.add(stopButton);
        westContainer.add(turnLeftButton);
        westContainer.add(turnRightButton);
        westContainer.add(pauseButton);
      
        
        // Set the command for each button
        moveButton.setCommand(new GameCommand(gm, "Move"));
        stopButton.setCommand(new GameCommand(gm, "Stop"));
        turnLeftButton.setCommand(new GameCommand(gm, "Left"));
        turnRightButton.setCommand(new GameCommand(gm, "Right"));
        pauseButton.setCommand(new GameCommand(gm, "Pause"));
        changeStrategiesButton.setCommand(new GameCommand(gm, "Change Strategies"));
        
        
        aboutButton.setCommand(new GameCommand(gm, "About"));
        exitButton.setCommand(new GameCommand(gm, "Exit"));

        // Add buttons to the side menu
        Toolbar tb = getToolbar();
        tb.addComponentToSideMenu(changeStrategiesButton);
        tb.addComponentToSideMenu(aboutButton);
        tb.addComponentToSideMenu(exitButton);
        tb.addCommandToRightBar(new GameCommand(gm, "Lecture Hall"));
        tb.addCommandToRightBar(new GameCommand(gm, "About"));
    }
    
	@Override
	public void run() {
		// Move the GameObject
	    gm.nextFrame();
	    viewMap.repaint();
		
	}

	
	
}
