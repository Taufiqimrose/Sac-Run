package com.csus.csc133;

public class Facility extends GameObject {

    public Facility(double x, double y) {
        super(0,0);
        
    }

	@Override
	public void handleCollide(Student s) {
		// TODO Auto-generated method stub
		
	}


    }


