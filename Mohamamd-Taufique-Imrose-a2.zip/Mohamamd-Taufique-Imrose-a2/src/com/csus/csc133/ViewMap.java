package com.csus.csc133;

import java.util.Observable;
import java.util.Observer;

import com.codename1.ui.Container;
import com.codename1.ui.plaf.Border;
import com.codename1.ui.plaf.Style;

public class ViewMap extends Container implements Observer {
      
    private GameModel gm;
    private int width;
    private int height;

    public ViewMap(int width, int height) {
        this.width = width;
        this.height = height;
        
        Style style = getAllStyles();
        style.setBorder(Border.createLineBorder(2, 0xff0000));
    }

	@Override
	public void update(Observable observable, Object data) {
		// TODO Auto-generated method stub
		
	}
    

 
    
}
