package com.csus.csc133;

public class Lecture {
    private int time;

    public Lecture(int time) {
        this.time = time;
    }

    public int getTime() {
        return time;
    }

    public void setTime(int time) {
        this.time = time;
    }

    public void end() {
        
        throw new UnsupportedOperationException("Unimplemented method 'end'");
    }
}
