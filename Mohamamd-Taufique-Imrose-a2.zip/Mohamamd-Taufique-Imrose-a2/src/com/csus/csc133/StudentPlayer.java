package com.csus.csc133;

public class StudentPlayer extends Student {
    private boolean isMoving;
    
    public StudentPlayer(int x, int y) {
        super(x, y, y);
        this.isMoving = false;
    }
    
    public void startMoving() {
        this.isMoving = true;
        setSpeed(getDefaultSpeed());
    }
    
    public void stopMoving() {
        this.isMoving = false;
        setSpeed(0);
    }
    
    public void turnLeft() {
        setHead(getHead() - 5);
    }
    
    public void turnRight() {
        setHead(getHead() + 5);
    }
    public void handleCollide(Student s) {
        Super(x, y);
        setTalkiveLevel(getTalkiveLevel() * 2);
        }

    private void Super(float x, float y) {
       
        throw new UnsupportedOperationException("Unimplemented method 'Super'");
    }
    }

