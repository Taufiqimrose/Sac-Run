package com.csus.csc133;

import com.codename1.ui.Container;
import com.codename1.ui.Display;
import com.codename1.ui.layouts.BorderLayout;
import com.codename1.ui.layouts.BoxLayout;
import com.codename1.ui.plaf.Border;
import com.codename1.ui.Label;
import java.util.Observable;
import java.util.Observer;

public class ViewStatus extends Container implements Observer {
    private Label lectureHallLabel;
    private Label lectureHallLabel1;
    private Label remainingTimeLabel;
    private Label currentTimeLabel;
    private Label absencesLabel;
    private Label hydrationLabel;
    private Label waterIntakeLabel;
    private Label timeRemainLabel;
    private GameModel gm;
    private Student student;
    private LectureHall lectureHall;
   
    public ViewStatus(GameModel gm, Student student, LectureHall lectureHall) {
        super(new BorderLayout());
        this.gm = gm;
        this.student = student;
        student = new Student(0, 0, 0);
        lectureHall = new LectureHall(0,0);
        gm.addObserver(this);
        Container labelsContainer = new Container(BoxLayout.y());
        getStyle().setBorder(Border.createLineBorder(2, 0xff0000));
        lectureHallLabel = new Label("Lecture Hall: \r\n");
        lectureHallLabel1 = new Label(lectureHall.getName());
        remainingTimeLabel = new Label("Remaining Time: "+lectureHall.getTime());
        currentTimeLabel = new Label("Current Time: \n" + gm.getGameTime());
        absencesLabel = new Label("Absences: " + student.getAbsenceTime());
        hydrationLabel = new Label("Hydration: \n" + student.getHydration());
        waterIntakeLabel = new Label("Water Intake: \n" + student.getWaterIntake());
        timeRemainLabel = new Label("Time Remain: \n" +student.getTimeRemain());

        labelsContainer.add(lectureHallLabel);
        labelsContainer.add(lectureHallLabel1);
        labelsContainer.add(remainingTimeLabel);
        labelsContainer.add(currentTimeLabel);
        labelsContainer.add(absencesLabel);
        labelsContainer.add(hydrationLabel);
        labelsContainer.add(waterIntakeLabel);
        labelsContainer.add(timeRemainLabel);

        addComponent(BorderLayout.CENTER, labelsContainer);
    }

    @Override
    public void update(Observable observable, Object arg) {
        // Update label text when game time changes
        if (observable instanceof GameModel) {
            GameModel gameModel = (GameModel) observable;
            currentTimeLabel.setText("Current Time: " + gameModel.getGameTime());
           
        }
  
    }
}
