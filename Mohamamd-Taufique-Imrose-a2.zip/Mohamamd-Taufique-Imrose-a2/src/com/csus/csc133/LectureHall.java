package com.csus.csc133;

class LectureHall extends Facility {
    private String name = "No Lecture";
    private Lecture currentLecture;
    private String time = null;

    public String getTime() {
		return time;
	}

	public void setTime(String time) {
		this.time = time;
	}

	public LectureHall(double x, double y) {
        super(x, y);
        this.name = name;
        this.currentLecture = currentLecture;
    }

    public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Lecture getCurrentLecture() {
		return currentLecture;
	}

	public void setCurrentLecture(Lecture currentLecture) {
		this.currentLecture = currentLecture;
	}

	@Override
    public void handleCollide(Student s) {
        if (s instanceof StudentPlayer) {
            currentLecture.end();
        }
    }
}