package com.csus.csc133;

import com.codename1.ui.Button;
import com.codename1.ui.plaf.Border;
import com.codename1.ui.plaf.Style;
import com.codename1.ui.plaf.UIManager;

public class ButtonStyles {

  

    public static void applyPrimaryButtonStyle(Button button) {
    	 
         button.getAllStyles().setBgColor(0xFF0000FF); // Green color
         button.getAllStyles().setFgColor(0xFFFFFF); // White text color
         button.getAllStyles().setBorder(Border.createLineBorder(2, 0x000000));
         button.getStyle().setBgColor(0xFF0000FF);
         button.getAllStyles().setBgTransparency(255);
    }
}
