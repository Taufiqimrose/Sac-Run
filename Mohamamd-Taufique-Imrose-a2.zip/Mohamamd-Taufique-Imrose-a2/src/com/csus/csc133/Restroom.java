package com.csus.csc133;

class Restroom extends Facility {
    public Restroom(double x, double y) {
        super(x, y);
    }

    @Override
    public void handleCollide(Student s) {
        if (s instanceof StudentPlayer) {
            s.clearWaterIntake();
        }
    }
}
