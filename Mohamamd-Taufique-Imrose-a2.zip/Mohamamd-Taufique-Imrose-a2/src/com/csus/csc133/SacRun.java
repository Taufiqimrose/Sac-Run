package com.csus.csc133;

import com.codename1.ui.*;
import com.codename1.ui.geom.Dimension;
import com.codename1.ui.layouts.BorderLayout;
import com.codename1.ui.layouts.BoxLayout;
import com.codename1.ui.layouts.GridLayout;
import com.codename1.ui.plaf.Border;
import com.codename1.ui.plaf.Style;
import com.codename1.ui.plaf.UIManager;
import com.csus.csc133.GameModel;
import com.csus.csc133.ButtonStyles;

public class SacRun extends Form {

    private GameModel gm;
    private ViewMap viewMap;
    private Student student;
    private LectureHall lectureHall;
    

    public SacRun() {
        

        // Initialize the GameModel with ViewMap's width and height
        gm = new GameModel();
        gm.init();

        // Set up the layout and add components
        A2();

        // Show the form
        show();
    }

    private void A2() {
        // Create the GUI components
    	// Initialize the ViewMap
        viewMap = new ViewMap(0,0);

        ViewStatus viewStatus = new ViewStatus(gm,student,lectureHall);

        ViewMessage viewMessage = new ViewMessage();
        ViewMessage.setMessage("Welcome! CSC 133-01 | Assignment 2 - Mohammad Taufique Imrose");

        // Set up the layout of the form
        setLayout(new BorderLayout());
        Container eastContainer = new Container(new BoxLayout(BoxLayout.Y_AXIS));
        Container westContainer = new Container(new GridLayout(3, 1));
        Container centerContainer = new Container(new BorderLayout());
        Container southContainer = new Container(new BorderLayout());

        // Add the GUI components to the containers
        eastContainer.add(viewStatus);
        centerContainer.add(BorderLayout.CENTER, viewMap);
        southContainer.add(BorderLayout.CENTER, viewMessage);

        // Add the containers to the form
        add(BorderLayout.EAST, eastContainer);
        add(BorderLayout.WEST, westContainer);
        add(BorderLayout.CENTER, centerContainer);
        add(BorderLayout.SOUTH, southContainer);

     // Create buttons
        Button moveButton = new Button("Move");
        Button stopButton = new Button("Stop");
        Button turnLeftButton = new Button("Turn Left");
        Button turnRightButton = new Button("Turn Right");
        Button changeStrategiesButton = new Button("Change Strategies");
        Button lectureHallButton = new Button("Lecture Hall");
        Button restroomButton = new Button("Restroom");
        Button waterDispenserButton = new Button("Water Dispenser");
        Button studentButton = new Button("Student");
        Button nextFrameButton = new Button("Next Frame");
        Button aboutButton = new Button("About");
        Button exitButton = new Button("Exit");
        
        Dimension buttonSize = new Dimension(450, 50); // Adjust the width and height as needed
        moveButton.setPreferredSize(buttonSize);
        stopButton.setPreferredSize(buttonSize);
        turnLeftButton.setPreferredSize(buttonSize);
        turnRightButton.setPreferredSize(buttonSize);
        lectureHallButton.setPreferredSize(buttonSize);
        restroomButton.setPreferredSize(buttonSize);
        waterDispenserButton.setPreferredSize(buttonSize);
        studentButton.setPreferredSize(buttonSize);
        nextFrameButton.setPreferredSize(buttonSize);
        aboutButton.setPreferredSize(buttonSize);
        exitButton.setPreferredSize(buttonSize);
        
        // Apply primary button style to each button
        ButtonStyles.applyPrimaryButtonStyle(moveButton);
        ButtonStyles.applyPrimaryButtonStyle(stopButton);
        ButtonStyles.applyPrimaryButtonStyle(turnLeftButton);
        ButtonStyles.applyPrimaryButtonStyle(turnRightButton);
        ButtonStyles.applyPrimaryButtonStyle(changeStrategiesButton);
        ButtonStyles.applyPrimaryButtonStyle(lectureHallButton);
        ButtonStyles.applyPrimaryButtonStyle(restroomButton);
        ButtonStyles.applyPrimaryButtonStyle(waterDispenserButton);
        ButtonStyles.applyPrimaryButtonStyle(studentButton);
        ButtonStyles.applyPrimaryButtonStyle(nextFrameButton);
        ButtonStyles.applyPrimaryButtonStyle(aboutButton);
        ButtonStyles.applyPrimaryButtonStyle(exitButton);


        // Add the command buttons to the west container
        westContainer.add(moveButton);
        westContainer.add(stopButton);
        westContainer.add(turnLeftButton);
        westContainer.add(turnRightButton);
        westContainer.add(lectureHallButton);
        westContainer.add(restroomButton);
        westContainer.add(waterDispenserButton);
        westContainer.add(studentButton);
        westContainer.add(nextFrameButton);

        // Set the command for each button
        moveButton.setCommand(new GameCommand(gm, "Move"));
        stopButton.setCommand(new GameCommand(gm, "Stop"));
        turnLeftButton.setCommand(new GameCommand(gm, "Left"));
        turnRightButton.setCommand(new GameCommand(gm, "Right"));
        lectureHallButton.setCommand(new GameCommand(gm, "Lecture Hall"));
        changeStrategiesButton.setCommand(new GameCommand(gm, "Change Strategies"));
        restroomButton.setCommand(new GameCommand(gm, "Restroom"));
        waterDispenserButton.setCommand(new GameCommand(gm, "Water Dispenser"));
        studentButton.setCommand(new GameCommand(gm, "Student"));
        nextFrameButton.setCommand(new GameCommand(gm, "Next Frame"));
        aboutButton.setCommand(new GameCommand(gm, "About"));
        exitButton.setCommand(new GameCommand(gm, "Exit"));

        // Add buttons to the side menu
        Toolbar tb = getToolbar();
        tb.addComponentToSideMenu(changeStrategiesButton);
        tb.addComponentToSideMenu(aboutButton);
        tb.addComponentToSideMenu(exitButton);
        tb.addCommandToRightBar(new GameCommand(gm, "Lecture Hall"));
        tb.addCommandToRightBar(new GameCommand(gm, "About"));
    }
}
