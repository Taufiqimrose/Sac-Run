package com.csus.csc133;

import com.codename1.charts.util.ColorUtil;

public abstract class GameObject {
    protected int x;
    protected int y;
    protected int color;
    protected int size;

    public GameObject(int x, int y) {
        this.x = x;
        this.y = y;
        this.color = ColorUtil.rgb(255, 0, 0); // Default color is red
        this.size = 0; // Default size
    }

    public abstract void handleCollide(Student s);
}
