package com.csus.csc133;

public class StudentRunning extends Student {
    private static final double SWEATING_RATE = 2.0;

    public StudentRunning(int x, int y) {
        super(x, y, y);
        setSweatingRate(SWEATING_RATE * 2);
    }
}
