package com.csus.csc133;

public class StudentSleeping extends Student {
    public StudentSleeping(int x, int y) {
        super(x, y, y);
    }

    @Override
    public void move() {
        // Sleeping students do not move
    }


}
