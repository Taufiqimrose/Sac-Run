package com.csus.csc133;
import java.util.Observable;
import java.util.Observer;

import com.codename1.ui.Container;
import com.codename1.ui.Label;
import com.codename1.ui.layouts.BorderLayout;
import com.codename1.ui.plaf.Border;
import com.codename1.ui.plaf.Style;


public class ViewMessage extends Container implements Observer {
    
    private static Label messageLabel;
    
    public ViewMessage() {
        super();
        setLayout(new BorderLayout());
        
        messageLabel = new Label();
        messageLabel.getAllStyles().setBorder(Border.createLineBorder(2, 0x000000));
        
        add(BorderLayout.CENTER, messageLabel);
    }
    
    public static void setMessage(String message) {
        messageLabel.setText(message);
    }

	@Override
	public void update(Observable observable, Object data) {
		// TODO Auto-generated method stub
		
	}
}
